export const SERVICES = [
  {
    id: "01",
    title: "Global Education",
    path: "/globalEducation",
    sheetUrl: "https://script.google.com/macros/s/AKfycbyoAukLg23UONl2ZpehNwjL9DnPF-KrgOCrqhaw4M0Bc7w9nf7ux8V-adIe8JKI7-pb/exec",
    icon: "🎓",
    desc: "Study abroad admissions, visa assistance, and complete passport support for aspiring students across India.",
    bg: "#e3f2fd",
    points: [
      "Study abroad guidance",
      "University admission support",
      "Visa assistance",
      "Scholarship help"
    ]
  },
  {
    id: "02",
   
    path: "/business",
    sheetUrl: "https://script.google.com/macros/s/AKfycbyGcnX27Wul_8O30wg45iEygv5Hh1MrtbZfMqfLZb6v1HawdDvx2e5dnNdAbjReMB7H/exec",
    icon: "🤝",
    title: "Business Setup",
    desc: "Company registration, GST filing, Udyam registration, and compliance support for startups and growing businesses.",
    bg: "#fff3e0",
    points: [
      "Pvt Ltd / LLP Registration",
      "GST Filing",
      "Udyam Registration",
      "Compliance support"
    ]
  },
    {
    id: "03",
    
    path: "/financial",
    sheetUrl: "https://script.google.com/macros/s/AKfycbxzRRReHCUVBKrBxHvh7CqoMV7z74hGH6Dsy1eVG95zs-nYQFQ3Kix57JsdmsiVTRxQig/exec",
    icon: "₹",
    title: "Financial Services",
    desc: "Business loans, CMA data preparation, and project report support for business growth and funding requirements.",
    bg: "#fce4ec",
    points: [
      "MSME Business Loans",
      "Mudra Scheme Assistance",
      "CMA Data Preparation",
      "Project Report Support"
    ]
  },
    {
    id: "04",
   
    path: "/tenders",
    sheetUrl: "https://script.google.com/macros/s/AKfycbx9Np_B5mjcR2ijWw-k0MEwlZuzx0lwTd1MjCAcIyT7TslCjBe3ISbz8Cw4H5v9sZqegQ/exec",
    icon: "⚖️",
    title: "Tender Services",
    desc: "End-to-end tender search, bid preparation support, GeM portal registration and management.",
    bg: "#e8f5e9",
    points: [
      "Tender Search & Selection",
      "Bid Preparation Support",
      "GeM Portal Registration",
      "Management Services"
    ]
  },
  ///
    {
    id: "05",
   
    path: "/fssai",
    sheetUrl: "https://script.google.com/macros/s/AKfycbx9Np_B5mjcR2ijWw-k0MEwlZuzx0lwTd1MjCAcIyT7TslCjBe3ISbz8Cw4H5v9sZqegQ/exec",
    icon: "⚖️",
    title: "FSSAI & Food Licensing",
    desc: "FSSAI registration, food safety documentation, and approval support for food businesses of all sizes.",
    bg: "#e8f5e9",
    points: [
      "Tender Search & Selection",
      "Bid Preparation Support",
      "GeM Portal Registration",
      "Management Services"
    ]
  },
     {
    id: "06",
   
    path: "/iso",
    sheetUrl: "https://script.google.com/macros/s/AKfycbx9Np_B5mjcR2ijWw-k0MEwlZuzx0lwTd1MjCAcIyT7TslCjBe3ISbz8Cw4H5v9sZqegQ/exec",
    icon: "⚖️",
    title: "ISO Certification",
    desc: "Complete support for major ISO certifications to improve business quality, compliance, and credibility.",
    bg: "#e8f5e9",
    points: [
      "Tender Search & Selection",
      "Bid Preparation Support",
      "GeM Portal Registration",
      "Management Services"
    ]
  },

     {
    id: "07",
   
    path: "/government-services",
    sheetUrl: "https://script.google.com/macros/s/AKfycbx9Np_B5mjcR2ijWw-k0MEwlZuzx0lwTd1MjCAcIyT7TslCjBe3ISbz8Cw4H5v9sZqegQ/exec",
    icon: "⚖️",
    title: "Essential Government Services",
    desc: "Easy assistance for Aadhaar, PAN, Voter ID, Driving License, and other essential public services.",
    bg: "#e8f5e9",
    points: [
      "Tender Search & Selection",
      "Bid Preparation Support",
      "GeM Portal Registration",
      "Management Services"
    ]
  },
  
];