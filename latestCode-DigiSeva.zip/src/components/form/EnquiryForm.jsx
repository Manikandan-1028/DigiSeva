import { Box, TextField, Button, Typography,Paper, MenuItem } from "@mui/material";
import { useState } from "react";
import { submitToSheet } from "../../utils/submitToSheet";
import toast from "react-hot-toast";
import ReactCountryFlag from "react-country-flag";


// export default function EnquiryForm({ serviceName, sheetUrl }) {
//   const [form, setForm] = useState({
//     name: "",
//     phone: "",
//     email: "",
//     message: ""
//   });

//   const [errors, setErrors] = useState({});

//   // ✅ VALIDATION
//   const validate = () => {
//     let newErrors = {};

//     if (!form.name.trim()) {
//       newErrors.name = "Name is required";
//     }

//     if (!form.phone) {
//       newErrors.phone = "Phone is required";
//     } else if (!/^[6-9]\d{9}$/.test(form.phone)) {
//       newErrors.phone = "Enter valid 10-digit number";
//     }

//     if (!form.email) {
//       newErrors.email = "Email is required";
//     } else if (
//       !/^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$/i.test(form.email)
//     ) {
//       newErrors.email = "Invalid email address";
//     }

//     if (!form.message.trim()) {
//       newErrors.message = "Message is required";
//     } else if (form.message.length < 10) {
//       newErrors.message = "Message should be at least 10 characters";
//     }

//     setErrors(newErrors);
//     return Object.keys(newErrors).length === 0;
//   };

//   const [loading, setLoading] = useState(false);
//   const [submitted, setSubmitted] = useState(false);

//   // ✅ SUBMIT
//   const handleSubmit = async () => {
//     if (!validate()) return;

//     setLoading(true);

//     try {
//       await submitToSheet({
//         ...form,
//         service: serviceName || "General Enquiry",
//       }, sheetUrl);

//       setSubmitted(true);
//       setForm({
//         name: "",
//         phone: "",
//         email: "",
//         message: "",
//       });
//       setTimeout(() => setSubmitted(false), 5000);
//     } catch (error) {
//       console.error("Error!", error.message);
//       alert("Something went wrong. Please try again.");
//     } finally {
//       setLoading(false);
//     }
//   };

//   return (
//      <Paper
//       elevation={4}
//       sx={{
//         width: "100%",
//         maxWidth: 380,
//         p: 3,
//         borderRadius: 4,
//         background: "#f9fafb"
//       }}
//     >
//       <Typography fontWeight={700} fontSize={20} mb={2}>
//         Register Now
//       </Typography>

//       {/* NAME */}
//       <Typography sx={{ fontSize: 14, mb: 0.5 }}>
//         Name <span style={{ color: "red" }}>*</span>
//       </Typography>
//       <TextField
//         fullWidth
//         placeholder="Enter your name"
//         value={form.name}
//         error={!!errors.name}
//         helperText={errors.name}
//         size="small"
//         sx={{ mb: 2 }}
//         onChange={(e) =>
//           setForm({ ...form, name: e.target.value })
//         }
//       />

//       {/* PHONE */}
//       <Typography sx={{ fontSize: 14, mb: 0.5 }}>
//         Mobile number <span style={{ color: "red" }}>*</span>
//       </Typography>
//       <TextField
//         fullWidth
//         placeholder="Enter your mobile number"
//         value={form.phone}
//         error={!!errors.phone}
//         helperText={errors.phone}
//         size="small"
//         sx={{ mb: 2 }}
//         onChange={(e) =>
//           setForm({ ...form, phone: e.target.value })
//         }
//       />

//       {/* EMAIL */}
//       <Typography sx={{ fontSize: 14, mb: 0.5 }}>
//         E-mail <span style={{ color: "red" }}>*</span>
//       </Typography>
//       <TextField
//         fullWidth
//         placeholder="Enter your email address"
//         value={form.email}
//         error={!!errors.email}
//         helperText={errors.email}
//         size="small"
//         sx={{ mb: 2 }}
//         onChange={(e) =>
//           setForm({ ...form, email: e.target.value })
//         }
//       />

//       {/* MESSAGE */}
//       <Typography sx={{ fontSize: 14, mb: 0.5 }}>
//         Your Message
//       </Typography>
//       <TextField
//         fullWidth
//         placeholder="Enter your message"
//         multiline
//         rows={3}
//         value={form.message}
//         error={!!errors.message}
//         helperText={errors.message}
//         size="small"
//         sx={{ mb: 2 }}
//         onChange={(e) =>
//           setForm({ ...form, message: e.target.value })
//         }
//       />

//       {/* TERMS */}
//       <Typography sx={{ fontSize: 12, color: "#777", mb: 2 }}>
//         ○ I agree with the Terms and Conditions
//       </Typography>

//       {/* BUTTON */}
//       <Button
//         variant="contained"
//         fullWidth
//         onClick={handleSubmit}
//         disabled={loading}
//         sx={{
//           py: 1.2,
//           borderRadius: 2,
//           textTransform: "none",
//           fontWeight: 600,
//           background: "linear-gradient(90deg,#1d8cf8,#0d6efd)"
//         }}
//       >
//         {loading ? "Sending..." : "Apply Now"}
//       </Button>

//       {/* SUCCESS */}
//       {submitted && (
//         <Typography
//           sx={{
//             mt: 2,
//             textAlign: "center",
//             color: "green",
//             fontWeight: 600
//           }}
//         >
//           ✓ Submitted Successfully!
//         </Typography>
//       )}
//     </Paper>
//     // <Box sx={{ maxWidth: 420 }}>
//     //   <Typography fontWeight={600} mb={2}>
//     //     Enquiry Form
//     //   </Typography>

//     //   <TextField
//     //     fullWidth
//     //     label="Name"
//     //     value={form.name}
//     //     error={!!errors.name}
//     //     helperText={errors.name}
//     //     sx={{ mb: 2 }}
//     //     onChange={(e) =>
//     //       setForm({ ...form, name: e.target.value })
//     //     }
//     //   />

//     //   <TextField
//     //     fullWidth
//     //     label="Phone"
//     //     value={form.phone}
//     //     error={!!errors.phone}
//     //     helperText={errors.phone}
//     //     sx={{ mb: 2 }}
//     //     onChange={(e) =>
//     //       setForm({ ...form, phone: e.target.value })
//     //     }
//     //   />

//     //   <TextField
//     //     fullWidth
//     //     label="Email"
//     //     value={form.email}
//     //     error={!!errors.email}
//     //     helperText={errors.email}
//     //     sx={{ mb: 2 }}
//     //     onChange={(e) =>
//     //       setForm({ ...form, email: e.target.value })
//     //     }
//     //   />

//     //   <TextField
//     //     fullWidth
//     //     label="Message"
//     //     multiline
//     //     rows={4}
//     //     value={form.message}
//     //     error={!!errors.message}
//     //     helperText={errors.message}
//     //     sx={{ mb: 2 }}
//     //     onChange={(e) =>
//     //       setForm({ ...form, message: e.target.value })
//     //     }
//     //   />

//     //   <Button 
//     //     variant="contained" 
//     //     fullWidth 
//     //     onClick={handleSubmit}
//     //     disabled={loading}
//     //   >
//     //     {loading ? "Sending..." : "Submit"}
//     //   </Button>

//     //   {submitted && (
//     //     <Typography color="success.main" sx={{ mt: 2, textAlign: "center", fontWeight: 600 }}>
//     //       ✓ Submitted Successfully!
//     //     </Typography>
//     //   )}
//     // </Box>
//   );
// }



const getInitialForm = () => ({
  name: "",
  phone: "",
  email: "",
  message: "",

  // Global
  preferredCountry: "",
  qualification: "",
  passportStatus: "",

  // Business
  businessName: "",
  businessType: "",
  serviceRequired: "",

  // Tender
  companyName: "",
  gemRegistration: "",

  // Finance
  financialService: "",
  loanAmount: "",
  businessLocation: "",

  // Food
  licenseType: "",
  existingLicense: "",

  // ISO
  industryType: "",
  isoType: "",
  employees: "",

  // Passport
  passportService: "",
  city: "",
  passportAvailable: "",

  // Government
  govService: "",
  applicationType: "",
});

export default function EnquiryForm({
  serviceName,
  sheetUrl,
  isGlobal,
  isBusiness,
  isTender,
  isFinance,
  isFood,
  isISO,
  isPassport,
  isGovernment,
}) {
  const [form, setForm] = useState(getInitialForm());

  const [errors, setErrors] = useState({});
  const [loading, setLoading] = useState(false);

  const handleChange = (field, value) => {
    setForm({
      ...form,
      [field]: value,
    });
  };

  // VALIDATION
  const validate = () => {
    let newErrors = {};

    if (!form.name.trim()) {
      newErrors.name = "Name is required";
    }

    if (!form.phone) {
      newErrors.phone = "Phone is required";
    } else if (!/^[6-9]\d{9}$/.test(form.phone)) {
      newErrors.phone = "Enter valid 10-digit number";
    }

    if (!form.email) {
      newErrors.email = "Email is required";
    }

    if (!form.message.trim()) {
      newErrors.message = "Message is required";
    }

    // GLOBAL
    if (isGlobal) {
      if (!form.preferredCountry) {
        newErrors.preferredCountry =
          "Preferred country required";
      }

      if (!form.qualification) {
        newErrors.qualification =
          "Qualification required";
      }

      if (!form.passportStatus) {
        newErrors.passportStatus =
          "Passport status required";
      }
    }

    // BUSINESS
    if (isBusiness) {
      if (!form.businessName) {
        newErrors.businessName =
          "Business name required";
      }

      if (!form.businessType) {
        newErrors.businessType =
          "Business type required";
      }

      if (!form.serviceRequired) {
        newErrors.serviceRequired =
          "Service required";
      }
    }

    // TENDER
    if (isTender) {
      if (!form.companyName) {
        newErrors.companyName =
          "Company name required";
      }

      if (!form.gemRegistration) {
        newErrors.gemRegistration =
          "Select GeM registration";
      }
    }

    // FINANCE
    if (isFinance) {
      if (!form.businessName) {
        newErrors.businessName =
          "Business name required";
      }

      if (!form.financialService) {
        newErrors.financialService =
          "Select financial service";
      }
    }

    // FOOD
    if (isFood) {
      if (!form.businessName) {
        newErrors.businessName =
          "Business name required";
      }

      if (!form.licenseType) {
        newErrors.licenseType =
          "Select license type";
      }

      if (!form.existingLicense) {
        newErrors.existingLicense =
          "Select existing license";
      }
    }

    // ISO
    if (isISO) {
      if (!form.companyName) {
        newErrors.companyName =
          "Company name required";
      }

      if (!form.industryType) {
        newErrors.industryType =
          "Industry type required";
      }

      if (!form.isoType) {
        newErrors.isoType =
          "Select ISO type";
      }
    }

    // PASSPORT
    if (isPassport) {
      if (!form.passportService) {
        newErrors.passportService =
          "Select passport service";
      }

      if (!form.city) {
        newErrors.city = "City required";
      }

      if (!form.passportAvailable) {
        newErrors.passportAvailable =
          "Select passport availability";
      }
    }

    // GOVERNMENT
    if (isGovernment) {
      if (!form.govService) {
        newErrors.govService =
          "Select government service";
      }

      if (!form.applicationType) {
        newErrors.applicationType =
          "Select application type";
      }

      if (!form.city) {
        newErrors.city = "City required";
      }
    }

    setErrors(newErrors);

    return Object.keys(newErrors).length === 0;
  };

  // SUBMIT
  const handleSubmit = async () => {
    if (!validate()) return;

    setLoading(true);

    try {
      await submitToSheet(
        {
          ...form,
          service: serviceName,
        },
        sheetUrl
      );

      toast.success("Submitted Successfully");

      setForm(getInitialForm());
    } catch (error) {
      console.error(error);
      toast.error("Something went wrong");
    } finally {
      setLoading(false);
    }
  };
  const Label = ({ text, required = true }) => (
  <Typography sx={{ fontSize: 14, mb: 0.5 }}>
    {text}
    {required && (
      <span style={{ color: "red" }}> *</span>
    )}
  </Typography>
);

  return (


<Paper
  elevation={4}
  sx={{
    width: "100%",
    maxWidth: { xs: "100%", md: 400 },
    p: { xs: 2, md: 3 },
    borderRadius: 4,
    background: "#f9fafb",
  }}
>
  {/* NAME */}
  <Label text="Full Name" />

  <TextField
    fullWidth
    size="small"
    placeholder="Enter your full name"
    value={form.name}
    error={!!errors.name}
    helperText={errors.name}
    sx={{ mb: 2 }}
    onChange={(e) =>
      handleChange("name", e.target.value)
    }
  />

  {/* PHONE */}
  <Label text="Phone Number" />

  <TextField
    fullWidth
    size="small"
    placeholder="Enter mobile number"
    value={form.phone}
    error={!!errors.phone}
    helperText={errors.phone}
    sx={{ mb: 2 }}
    onChange={(e) =>
      handleChange("phone", e.target.value)
    }
  />

  {/* EMAIL */}
  <Label text="Email Address" />

  <TextField
    fullWidth
    size="small"
    placeholder="Enter email address"
    value={form.email}
    error={!!errors.email}
    helperText={errors.email}
    sx={{ mb: 2 }}
    onChange={(e) =>
      handleChange("email", e.target.value)
    }
  />

  {/* GLOBAL EDUCATION */}
  {isGlobal && (
    <>
      <Label text="Preferred Country" />

    <TextField
  select
  fullWidth
  size="small"
  value={form.preferredCountry}
  error={!!errors.preferredCountry}
  helperText={errors.preferredCountry}
  sx={{ mb: 2 }}
  onChange={(e) =>
    handleChange(
      "preferredCountry",
      e.target.value
    )
  }
>
  <MenuItem value="Canada">
    <ReactCountryFlag
      countryCode="CA"
      svg
      style={{
        width: "1.5em",
        height: "1.5em",
        marginRight: 8,
      }}
    />
    Canada
  </MenuItem>

  <MenuItem value="United Kingdom">
    <ReactCountryFlag
      countryCode="GB"
      svg
      style={{
        width: "1.5em",
        height: "1.5em",
        marginRight: 8,
      }}
    />
    United Kingdom
  </MenuItem>

  <MenuItem value="United States">
    <ReactCountryFlag
      countryCode="US"
      svg
      style={{
        width: "1.5em",
        height: "1.5em",
        marginRight: 8,
      }}
    />
    United States
  </MenuItem>

  <MenuItem value="Australia">
    <ReactCountryFlag
      countryCode="AU"
      svg
      style={{
        width: "1.5em",
        height: "1.5em",
        marginRight: 8,
      }}
    />
    Australia
  </MenuItem>

  <MenuItem value="Germany">
    <ReactCountryFlag
      countryCode="DE"
      svg
      style={{
        width: "1.5em",
        height: "1.5em",
        marginRight: 8,
      }}
    />
    Germany
  </MenuItem>

  <MenuItem value="New Zealand">
    <ReactCountryFlag
      countryCode="NZ"
      svg
      style={{
        width: "1.5em",
        height: "1.5em",
        marginRight: 8,
      }}
    />
    New Zealand
  </MenuItem>

  <MenuItem value="Ireland">
    <ReactCountryFlag
      countryCode="IE"
      svg
      style={{
        width: "1.5em",
        height: "1.5em",
        marginRight: 8,
      }}
    />
    Ireland
  </MenuItem>

  <MenuItem value="France">
    <ReactCountryFlag
      countryCode="FR"
      svg
      style={{
        width: "1.5em",
        height: "1.5em",
        marginRight: 8,
      }}
    />
    France
  </MenuItem>

  <MenuItem value="Singapore">
    <ReactCountryFlag
      countryCode="SG"
      svg
      style={{
        width: "1.5em",
        height: "1.5em",
        marginRight: 8,
      }}
    />
    Singapore
  </MenuItem>
</TextField>

      <Label text="Highest Qualification" />

      <TextField
        fullWidth
        size="small"
        placeholder="Enter highest qualification"
        value={form.qualification}
        error={!!errors.qualification}
        helperText={errors.qualification}
        sx={{ mb: 2 }}
        onChange={(e) =>
          handleChange(
            "qualification",
            e.target.value
          )
        }
      />

      <Label text="Passport Status" />

      <TextField
        select
        fullWidth
        size="small"
        value={form.passportStatus}
        error={!!errors.passportStatus}
        helperText={errors.passportStatus}
        displayEmpty
        sx={{ mb: 2 }}
        onChange={(e) =>
          handleChange(
            "passportStatus",
            e.target.value
          )
        }
      >
        <MenuItem value="">
          Select Passport Status
        </MenuItem>

        <MenuItem value="Yes">Yes</MenuItem>
        <MenuItem value="No">No</MenuItem>
        <MenuItem value="Applied">
          Applied
        </MenuItem>
      </TextField>
    </>
  )}

  {/* BUSINESS SETUP */}
  {isBusiness && (
    <>
      <Label text="Business Name" />

      <TextField
        fullWidth
        size="small"
        placeholder="Enter business name"
        value={form.businessName}
        error={!!errors.businessName}
        helperText={errors.businessName}
        sx={{ mb: 2 }}
        onChange={(e) =>
          handleChange(
            "businessName",
            e.target.value
          )
        }
      />

      <Label text="Business Type" />

      <TextField
        select
        fullWidth
        size="small"
        value={form.businessType}
        error={!!errors.businessType}
        helperText={errors.businessType}
        displayEmpty
        sx={{ mb: 2 }}
        onChange={(e) =>
          handleChange(
            "businessType",
            e.target.value
          )
        }
      >
        <MenuItem value="">
          Select Business Type
        </MenuItem>

        <MenuItem value="Pvt Ltd">
          Pvt Ltd
        </MenuItem>

        <MenuItem value="LLP">LLP</MenuItem>

        <MenuItem value="OPC">OPC</MenuItem>

        <MenuItem value="Proprietorship">
          Proprietorship
        </MenuItem>
      </TextField>

      <Label text="Service Required" />

      <TextField
        select
        fullWidth
        size="small"
        value={form.serviceRequired}
        error={!!errors.serviceRequired}
        helperText={errors.serviceRequired}
        displayEmpty
        sx={{ mb: 2 }}
        onChange={(e) =>
          handleChange(
            "serviceRequired",
            e.target.value
          )
        }
      >
        <MenuItem value="">
          Select Service
        </MenuItem>

        <MenuItem value="Company Registration">
          Company Registration
        </MenuItem>

        <MenuItem value="GST">GST</MenuItem>

        <MenuItem value="Udyam">
          Udyam
        </MenuItem>

        <MenuItem value="Compliance">
          Compliance
        </MenuItem>
      </TextField>
    </>
  )}

  {/* TENDER */}
  {isTender && (
    <>
      <Label text="Company Name" />

      <TextField
        fullWidth
        size="small"
        placeholder="Enter company name"
        value={form.companyName}
        error={!!errors.companyName}
        helperText={errors.companyName}
        sx={{ mb: 2 }}
        onChange={(e) =>
          handleChange(
            "companyName",
            e.target.value
          )
        }
      />

      <Label text="GeM Registration Available" />

      <TextField
        select
        fullWidth
        size="small"
        value={form.gemRegistration}
        error={!!errors.gemRegistration}
        helperText={errors.gemRegistration}
        displayEmpty
        sx={{ mb: 2 }}
        onChange={(e) =>
          handleChange(
            "gemRegistration",
            e.target.value
          )
        }
      >
        <MenuItem value="">
          Select Option
        </MenuItem>

        <MenuItem value="Yes">Yes</MenuItem>

        <MenuItem value="No">No</MenuItem>
      </TextField>
    </>
  )}

  {/* FINANCIAL SERVICES */}
  {isFinance && (
    <>
      <Label text="Business Name" />

      <TextField
        fullWidth
        size="small"
        placeholder="Enter business name"
        value={form.businessName}
        error={!!errors.businessName}
        helperText={errors.businessName}
        sx={{ mb: 2 }}
        onChange={(e) =>
          handleChange(
            "businessName",
            e.target.value
          )
        }
      />

      <Label text="Financial Service Required" />

      <TextField
        select
        fullWidth
        size="small"
        value={form.financialService}
        error={!!errors.financialService}
        helperText={errors.financialService}
        displayEmpty
        sx={{ mb: 2 }}
        onChange={(e) =>
          handleChange(
            "financialService",
            e.target.value
          )
        }
      >
        <MenuItem value="">
          Select Financial Service
        </MenuItem>

        <MenuItem value="Business Loan">
          Business Loan
        </MenuItem>

        <MenuItem value="CMA Data">
          CMA Data
        </MenuItem>

        <MenuItem value="Project Report">
          Project Report
        </MenuItem>
      </TextField>

      <Label
        text="Loan Amount Required"
        required={false}
      />

      <TextField
        fullWidth
        size="small"
        placeholder="Enter required loan amount"
        value={form.loanAmount}
        sx={{ mb: 2 }}
        onChange={(e) =>
          handleChange(
            "loanAmount",
            e.target.value
          )
        }
      />

      <Label
        text="Business Location"
        required={false}
      />

      <TextField
        fullWidth
        size="small"
        placeholder="Enter business location"
        value={form.businessLocation}
        sx={{ mb: 2 }}
        onChange={(e) =>
          handleChange(
            "businessLocation",
            e.target.value
          )
        }
      />
    </>
  )}

  {/* FOOD / FSSAI */}
  {isFood && (
    <>
      <Label text="Business Name" />

      <TextField
        fullWidth
        size="small"
        placeholder="Enter business name"
        value={form.businessName}
        error={!!errors.businessName}
        helperText={errors.businessName}
        sx={{ mb: 2 }}
        onChange={(e) =>
          handleChange(
            "businessName",
            e.target.value
          )
        }
      />

      <Label text="License Type" />

      <TextField
        select
        fullWidth
        size="small"
        value={form.licenseType}
        error={!!errors.licenseType}
        helperText={errors.licenseType}
        displayEmpty
        sx={{ mb: 2 }}
        onChange={(e) =>
          handleChange(
            "licenseType",
            e.target.value
          )
        }
      >
        <MenuItem value="">
          Select License Type
        </MenuItem>

        <MenuItem value="Basic">
          Basic
        </MenuItem>

        <MenuItem value="State">
          State
        </MenuItem>

        <MenuItem value="Central">
          Central
        </MenuItem>
      </TextField>

      <Label text="Existing License" />

      <TextField
        select
        fullWidth
        size="small"
        value={form.existingLicense}
        error={!!errors.existingLicense}
        helperText={errors.existingLicense}
        displayEmpty
        sx={{ mb: 2 }}
        onChange={(e) =>
          handleChange(
            "existingLicense",
            e.target.value
          )
        }
      >
        <MenuItem value="">
          Select Option
        </MenuItem>

        <MenuItem value="Yes">Yes</MenuItem>

        <MenuItem value="No">No</MenuItem>
      </TextField>
    </>
  )}

  {/* ISO */}
  {isISO && (
    <>
      <Label text="Company Name" />

      <TextField
        fullWidth
        size="small"
        placeholder="Enter company name"
        value={form.companyName}
        error={!!errors.companyName}
        helperText={errors.companyName}
        sx={{ mb: 2 }}
        onChange={(e) =>
          handleChange(
            "companyName",
            e.target.value
          )
        }
      />

      <Label text="Industry Type" />

      <TextField
        fullWidth
        size="small"
        placeholder="Enter industry type"
        value={form.industryType}
        error={!!errors.industryType}
        helperText={errors.industryType}
        sx={{ mb: 2 }}
        onChange={(e) =>
          handleChange(
            "industryType",
            e.target.value
          )
        }
      />

      <Label text="ISO Type" />

      <TextField
        select
        fullWidth
        size="small"
        value={form.isoType}
        error={!!errors.isoType}
        helperText={errors.isoType}
        displayEmpty
        sx={{ mb: 2 }}
        onChange={(e) =>
          handleChange(
            "isoType",
            e.target.value
          )
        }
      >
        <MenuItem value="">
          Select ISO Type
        </MenuItem>

        <MenuItem value="9001">
          ISO 9001
        </MenuItem>

        <MenuItem value="22000">
          ISO 22000
        </MenuItem>

        <MenuItem value="27001">
          ISO 27001
        </MenuItem>

        <MenuItem value="Other">
          Other
        </MenuItem>
      </TextField>

      <Label
        text="Number of Employees"
        required={false}
      />

      <TextField
        fullWidth
        size="small"
        placeholder="Enter employee count"
        value={form.employees}
        sx={{ mb: 2 }}
        onChange={(e) =>
          handleChange(
            "employees",
            e.target.value
          )
        }
      />

      <Label
        text="Business Location"
        required={false}
      />

      <TextField
        fullWidth
        size="small"
        placeholder="Enter business location"
        value={form.businessLocation}
        sx={{ mb: 2 }}
        onChange={(e) =>
          handleChange(
            "businessLocation",
            e.target.value
          )
        }
      />
    </>
  )}

  {isGovernment && (
        <>
          <Typography sx={{ fontSize: 14, mb: 0.5 }}>
            Service Required *
          </Typography>

          <TextField
            select
            fullWidth
            size="small"
            value={form.govService}
            error={!!errors.govService}
            helperText={errors.govService}
            sx={{ mb: 2 }}
            onChange={(e) =>
              setForm({
                ...form,
                govService: e.target.value,
              })
            }
          >
            <MenuItem value="Aadhaar">
              Aadhaar
            </MenuItem>

            <MenuItem value="PAN">
              PAN
            </MenuItem>

            <MenuItem value="Voter ID">
              Voter ID
            </MenuItem>

            <MenuItem value="Driving License">
              Driving License
            </MenuItem>

            <MenuItem value="Passport">
              Passport
            </MenuItem>

            <MenuItem value="Ration Card">
              Ration Card
            </MenuItem>

            <MenuItem value="PMJAY">
              PMJAY
            </MenuItem>
          </TextField>

          <Typography sx={{ fontSize: 14, mb: 0.5 }}>
            Application Type *
          </Typography>

          <TextField
            select
            fullWidth
            size="small"
            value={form.applicationType}
            error={!!errors.applicationType}
            helperText={errors.applicationType}
            sx={{ mb: 2 }}
            onChange={(e) =>
              setForm({
                ...form,
                applicationType: e.target.value,
              })
            }
          >
            <MenuItem value="New">New</MenuItem>
            <MenuItem value="Renewal">
              Renewal
            </MenuItem>
            <MenuItem value="Update">
              Update
            </MenuItem>
            <MenuItem value="Correction">
              Correction
            </MenuItem>
          </TextField>

          <Typography sx={{ fontSize: 14, mb: 0.5 }}>
            City *
          </Typography>

          <TextField
            fullWidth
            size="small"
            placeholder="Enter city"
            value={form.city}
            error={!!errors.city}
            helperText={errors.city}
            sx={{ mb: 2 }}
            onChange={(e) =>
              setForm({
                ...form,
                city: e.target.value,
              })
            }
          />
        </>
      )}

  {/* MESSAGE */}
  <Label text="Message" />

  <TextField
    fullWidth
    multiline
    rows={3}
    size="small"
    placeholder="Enter your message"
    value={form.message}
    error={!!errors.message}
    helperText={errors.message}
    sx={{ mb: 2 }}
    onChange={(e) =>
      handleChange("message", e.target.value)
    }
  />

  {/* BUTTON */}
  <Button
    variant="contained"
    fullWidth
    onClick={handleSubmit}
    disabled={loading}
    sx={{
      py: 1.2,
      borderRadius: 2,
      textTransform: "none",
      fontWeight: 600,
      background:
        "linear-gradient(90deg,#1d8cf8,#0d6efd)",
    }}
  >
    {loading ? "Sending..." : "Apply Now"}
  </Button>
</Paper>
  );
}