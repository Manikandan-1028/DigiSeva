import {
  Box,
  Typography,
  Grid,
  Card,
  CardContent
} from "@mui/material";
import ServiceBox from "../../components/service/ServiceBox";
import { SERVICES } from "../../data/servicesData";

const services = [
  {
    id: "01",
    icon: "🎓",
    title: "Global Education",
    desc: "Study abroad admissions, visa assistance, and complete passport support for aspiring students across India.",
    bg: "#e3f2fd",
    path:"/business"
  },
  {
    id: "02",
    icon: "🤝",
    title: "Business Setup",
    desc: "Pvt Ltd, LLP, OPC registration, GST filing, Udyam certification and full compliance management.",
    bg: "#fff3e0",
     path:"/"
  },
  {
    id: "03",
    icon: "⚖️",
    title: "Government Tenders",
    desc: "End-to-end tender search, bid preparation support, GeM portal registration and management.",
    bg: "#e8f5e9",
     path:"/business"
  },
  {
    id: "04",
    icon: "₹",
    title: "Financial Services",
    desc: "Business loans for MSME, Mudra scheme, CMA data preparation and comprehensive project reports.",
    bg: "#fce4ec",
     path:"/business"
  }
];

export default function ServicesSection() {
  return (
    <Box sx={{ py: 8, px: { xs: 2, md: 6 }, backgroundColor: "#f9f9f9" }}>
      
      {/* Top Heading */}
      <Typography
        sx={{
          color: "#c89b3c",
          letterSpacing: 2,
          fontSize: "14px",
          mb: 1
        }}
      >
        WHAT WE OFFER
      </Typography>

      <Typography
        variant="h3"
        sx={{
          fontWeight: 700,
          mb: 5,
          fontSize: { xs: "28px", md: "42px" }
        }}
      >
        Everything Your Business{" "}
        <Box component="span" sx={{ color: "#c89b3c", fontStyle: "italic" }}>
          Needs
        </Box>
      </Typography>

      {/* Cards */}
      <Box
  sx={{
    display: "grid",
    gridTemplateColumns: {
      xs: "1fr",          // mobile → 1 column
      sm: "1fr 1fr",      // tablet → 2 columns
      md: "repeat(3, 1fr)" ,// desktop → 4 columns ✅
      lg: "repeat(4, 1fr)" // desktop → 4 columns ✅

    },
    gap: 3
  }}
>
  {SERVICES.map((item,index) => (
    <Box
    key={item.id}
    data-aos="zoom-in"
    data-aos-delay={index * 100}
  >
    <ServiceBox item={item} />
  </Box>
  ))}
</Box>
      {/* <Grid container spacing={3}>
        {services.map((item) => (
          <Grid item xs={12} sm={6} md={3} key={item.id}>
                <ServiceBox item={item}/>
          </Grid>
        ))}
      </Grid> */}
    </Box>
  );
}