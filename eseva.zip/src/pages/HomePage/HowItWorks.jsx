import { Box, Typography } from "@mui/material";

const steps = [
  {
    id: "01",
    title: "Choose Your Service",
    desc: "Select the service that matches your needs."
  },
  {
    id: "02",
    title: "Fill Out the Form",
    desc: "Provide your basic details to get started."
  },
  {
    id: "03",
    title: "We Contact You",
    desc: "Our team reaches out to understand your requirements."
  },
  {
    id: "04",
    title: "We Handle the Process",
    desc: "Sit back while we take care of everything for you."
  }
];

export default function HowItWorks() {
  return (
    <Box
      sx={{
        py: 5,
        textAlign: "center",
        background: "#f9fbff",
        position: "relative",
        // boxShadow:2,
        overflow: "hidden"
      }}
    >
      {/* HEADER */}
      <Typography variant="h4" fontWeight={700}>
        How it{" "}
        <Box component="span" sx={{ color: "#f4a940" }}>
          works
        </Box>
      </Typography>

      <Typography sx={{ mt: 1, color: "#6b7280" }}>
        Our Service process process
      </Typography>

      {/* LINE UNDER TEXT */}
      <Box
        sx={{
          width: 200,
          height: 2,
          background: "#1e5fa3",
          mx: "auto",
          mt: 2,
          position: "relative"
        }}
      >
        <Box
          sx={{
            width: 8,
            height: 8,
            background: "#1e5fa3",
            borderRadius: "50%",
            position: "absolute",
            left: 0,
            top: -3
          }}
        />
        <Box
          sx={{
            width: 8,
            height: 8,
            background: "#1e5fa3",
            borderRadius: "50%",
            position: "absolute",
            right: 0,
            top: -3
          }}
        />
      </Box>

      {/* STEPS */}
      <Box
        sx={{
          mt: 8,
          display: "flex",
          justifyContent: "center",
          alignItems: "flex-start",
          flexWrap: "wrap",
          gap: { xs: 4, md: 6 },
          position: "relative"
        }}
      >
        {/* DOTTED LINE */}
        <Box
          sx={{
            position: "absolute",
            top: 40,
            left: "10%",
            right: "10%",
            borderTop: "2px dashed #f4a940",
            zIndex: 0,
            display: { xs: "none", md: "block" }
          }}
        />

        {steps.map((step) => (
          <Box
            key={step.id}
            sx={{
              width: { xs: "100%", sm: "45%", md: "22%" },
              textAlign: "center",
              position: "relative",
              zIndex: 1
            }}
          >
            {/* CIRCLE */}
            <Box
              sx={{
                width: 70,
                height: 70,
                borderRadius: "50%",
                border: "2px solid #3b82f6",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                mx: "auto",
                mb: 2,
                fontWeight: 700,
                fontSize: "22px",
                color: "#5b3a29",
                background: "#fff"
              }}
            >
              {step.id}
            </Box>

            {/* TITLE */}
            <Typography
              sx={{
                fontWeight: 600,
                color: "#1e5fa3",
                mb: 1
              }}
            >
              {step.title}
            </Typography>

            {/* DESC */}
            <Typography
              sx={{
                fontSize: "14px",
                color: "#6b7280",
                maxWidth: 220,
                mx: "auto",
                lineHeight: 1.6
              }}
            >
              {step.desc}
            </Typography>
          </Box>
        ))}
      </Box>

      {/* OPTIONAL WAVE BG */}
      <Box
        sx={{
          position: "absolute",
          bottom: 0,
          left: 0,
          width: "100%",
          height: 120,
          background:
            "radial-gradient(circle at 10% 50%, rgba(30,95,163,0.08) 20%, transparent 20%)",
          opacity: 0.4
        }}
      />
    </Box>
  );
}