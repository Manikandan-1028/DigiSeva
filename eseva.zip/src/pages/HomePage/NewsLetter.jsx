import { Box, Typography, TextField, Button, Paper } from "@mui/material";
import { useState } from "react";
import { submitToSheet } from "../../utils/submitToSheet";
// import MailOutlineIcon from "@mui/icons-material/MailOutline";

export default function Newsletter() {
  const [email, setEmail] = useState("");
  const [loading, setLoading] = useState(false);
  const [msg, setMsg] = useState("");

  const handleSubscribe = async () => {
    if (!email || !email.includes("@")) {
      alert("Please enter a valid email");
      return;
    }

    setLoading(true);
    try {
      await submitToSheet(
        {
          mail_id: email,
          action: "Newsletter Subscription",
        },
        "https://script.google.com/macros/s/AKfycbxqHAb2-6KGyn2KQwPAiaOb5twec9YFz0ST8_fd7eI-ncS24QHSw6NyhY_2QJ3FkKv8/exec"
      );
      setMsg("Thank you for subscribing!");
      setEmail("");
    } catch (error) {
      alert("Error subscribing.");
    } finally {
      setLoading(false);
    }
  };

  return (
     <Box sx={{ py: 10, px: 2, display: "flex", justifyContent: "center" }}>
      <Paper
        elevation={3}
        sx={{
          maxWidth: "1100px",
          width: "100%",
          borderRadius: 4,
          p: { xs: 3, md: 5 },
          display: "flex",
          flexDirection: { xs: "column", md: "row" },
          alignItems: "center",
          gap: 4,
          background: "#f8fafc"
        }}
      >
        {/* LEFT ICON */}
        <Box
          sx={{
            background: "#e3f2fd",
            p: 3,
            borderRadius: "20px",
            display: "flex",
            alignItems: "center",
            justifyContent: "center"
          }}
        >
          {/* <MailOutlineIcon sx={{ fontSize: 60, color: "#1976d2" }} /> */}
        </Box>

        {/* RIGHT CONTENT */}
        <Box sx={{ flex: 1 }}>
          <Typography variant="h5" fontWeight={700}>
            Stay Ahead with DigiSeva
          </Typography>

          <Typography sx={{ mt: 1, color: "text.secondary" }}>
            Get tender alerts, government scheme updates, business tips,
            and exclusive offers delivered to your inbox.
          </Typography>

          {/* INPUT + BUTTON */}
          <Box
            sx={{
              mt: 3,
              display: "flex",
              flexDirection: { xs: "column", sm: "row" },
              gap: 2
            }}
          >
            <TextField
              fullWidth
              placeholder="Enter your E-mail Address"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              sx={{
                background: "#fff",
                borderRadius: 2
              }}
            />

            <Button
              variant="contained"
              onClick={handleSubscribe}
              disabled={loading}
              sx={{
                px: 4,
                borderRadius: 2,
                textTransform: "none",
                fontWeight: 600
              }}
            >
              {loading ? "Submitting..." : "Submit"}
            </Button>
          </Box>

          {/* FEATURES */}
          <Typography
            sx={{
              mt: 2,
              fontSize: "0.85rem",
              color: "text.secondary"
            }}
          >
            ✔ Weekly Tender Alerts &nbsp; ✔ Govt. Scheme Updates &nbsp;
            ✔ Business Tips &nbsp; ✔ Exclusive Offers
          </Typography>

          {msg && (
            <Typography sx={{ mt: 1, color: "green", fontWeight: 600 }}>
              {msg}
            </Typography>
          )}
        </Box>
      </Paper>
    </Box>
  );
}