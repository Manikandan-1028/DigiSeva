// import {
//   Box,
//   Typography,
//   TextField,
//   Button,
//   Paper
// } from "@mui/material";
// import EnquiryForm from "../../components/form/EnquiryForm";

// export default function Business() {
//   return (
//     <Box
//       sx={{
//         py: 10,
//         px: 2,
//         background: "#f3f4f6"
//       }}
//     >
//       {/* CENTER WRAPPER */}
//       <Box
//         sx={{
//           maxWidth: "1000px",
//           mx: "auto"
//         }}
//       >
//         <Paper
//           elevation={3}
//           sx={{
//             p: { xs: 3, md: 6 },
//             borderRadius: 5,
//             background: "#fff"
//           }}
//         >
//           <Box
//             sx={{
//               display: "flex",
//               flexDirection: { xs: "column", md: "row" },
//               gap: 5
//             }}
//           >
//             {/* LEFT SIDE */}
//             <Box sx={{ flex: 1 }}>
//               <Typography
//                 variant="h4"
//                 sx={{ fontWeight: 700, mb: 2 }}
//               >
//                 Business Setup
//               </Typography>

//               <Typography sx={{ color: "#6b7280", mb: 3 }}>
//                 Fill out the form and our team will contact you shortly.
//               </Typography>

//               <Box sx={{ display: "flex", flexDirection: "column", gap: 2 }}>
//                 {[
//                   "Quick response within 24 hours",
//                   "Trusted by 25,000+ clients",
//                   "Affordable & transparent pricing",
//                   "End-to-end assistance"
//                 ].map((point, i) => (
//                   <Box key={i} sx={{ display: "flex", gap: 1.5 }}>
//                     <Box
//                       sx={{
//                         width: 8,
//                         height: 8,
//                         mt: "8px",
//                         borderRadius: "50%",
//                         backgroundColor: "#c89b3c"
//                       }}
//                     />
//                     <Typography>{point}</Typography>
//                   </Box>
//                 ))}
//               </Box>
//             </Box>

//             <EnquiryForm
//               serviceName="Business Setup"
//               sheetUrl="https://script.google.com/macros/s/AKfycbyGcnX27Wul_8O30wg45iEygv5Hh1MrtbZfMqfLZb6v1HawdDvx2e5dnNdAbjReMB7H/exec"
//             />
//           </Box>
//         </Paper>
//       </Box>
//     </Box>
//   );
// }

import {
  Box,
  Typography,
  Paper,
  TextField,
  Button
} from "@mui/material";
import SchoolIcon from "@mui/icons-material/School";
import PublicIcon from "@mui/icons-material/Public";
import SecurityIcon from "@mui/icons-material/Security";
import BoltIcon from "@mui/icons-material/Bolt";
import StarIcon from "@mui/icons-material/Star";
import EnquiryForm from "../../components/form/EnquiryForm";

export default function GlobalEducation() {
  return (
    <Box sx={{ bgcolor: "#eef1f5", py: 8, px: 2 }}>
      <Box sx={{ maxWidth: "1200px", mx: "auto" }}>
        
        {/* MAIN CONTAINER */}
        <Box
          sx={{
            display: "flex",
            flexDirection: { xs: "column", md: "row" },
            gap: 5,
            p: { xs: 3, md: 6 },
            borderRadius: 6,
            background: "linear-gradient(180deg,#f9fafb,#dbeafe)",
          }}
        >
          
          {/* LEFT SIDE */}
          <Box sx={{ flex: 1 }}>
            
            {/* ICON */}
            <Box
              sx={{
                width: 70,
                height: 70,
                borderRadius: "50%",
                bgcolor: "#dbeafe",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                mb: 2
              }}
            >
              <SchoolIcon sx={{ fontSize: 35, color: "#1976d2" }} />
            </Box>

            <Typography variant="h3" fontWeight={700}>
              Global Education
            </Typography>

            <Typography sx={{ mt: 2, color: "#6b7280", maxWidth: 500 }}>
              Study abroad admissions, visa assistance, and complete passport
              support for aspiring students across India.
            </Typography>

            {/* STATS */}
            <Paper
              elevation={3}
              sx={{
                mt: 4,
                p: 3,
                borderRadius: 4,
                display: "flex",
                justifyContent: "space-between",
                textAlign: "center"
              }}
            >
              {[
                ["25K+", "Happy Clients"],
                ["500+", "Services"],
                ["4.8", "Rating"],
                ["5yr", "Of Excellence"]
              ].map((item, i) => (
                <Box key={i} sx={{ flex: 1 }}>
                  <Typography fontSize={28} fontWeight={700}>
                    {item[0]} {i === 2 && <StarIcon sx={{ color: "#f4a100" }} />}
                  </Typography>
                  <Typography sx={{ color: "#777" }}>
                    {item[1]}
                  </Typography>
                </Box>
              ))}
            </Paper>

            {/* FEATURES */}
            <Box
              sx={{
                mt: 4,
                display: "grid",
                gridTemplateColumns: { xs: "1fr", sm: "1fr 1fr" },
                gap: 2
              }}
            >
              {[
                ["Nation-wide Reach", <PublicIcon />],
                ["Professional Experts", <SchoolIcon />],
                ["Secure & Certified", <SecurityIcon />],
                ["Fast Processing", <BoltIcon />]
              ].map((item, i) => (
                <Paper
                  key={i}
                  sx={{
                    p: 2,
                    borderRadius: 3,
                    display: "flex",
                    alignItems: "center",
                    gap: 2
                  }}
                >
                  <Box
                    sx={{
                      width: 45,
                      height: 45,
                      borderRadius: 2,
                      bgcolor: "#e0f2fe",
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "center"
                    }}
                  >
                    {item[1]}
                  </Box>
                  <Typography fontWeight={600}>
                    {item[0]}
                  </Typography>
                </Paper>
              ))}
            </Box>
          </Box>


             <EnquiryForm
               serviceName="Business Setup"
               sheetUrl="https://script.google.com/macros/s/AKfycbyGcnX27Wul_8O30wg45iEygv5Hh1MrtbZfMqfLZb6v1HawdDvx2e5dnNdAbjReMB7H/exec"
             />
        </Box>
      </Box>
    </Box>
  );
}