import { useState } from "react";
import {
  AppBar,
  Toolbar,
  Typography,
  Button,
  Box,
  IconButton,
  Drawer,
  List,
  ListItem,
  ListItemButton,
  ListItemText,
} from "@mui/material";
import MenuIcon from "@mui/icons-material/Menu";
import { Link, useLocation } from "react-router-dom";

const navLinks = [
  { label: "Home", path: "/" },
  { label: "Business SetUp", path: "/business" },
  { label: "Financial", path: "/financial" },
  { label: "Tenders", path: "/tenders" },
  { label: "Global", path: "/globalEducation" },
];

export default function Navbar() {
  const [open, setOpen] = useState(false);
const location = useLocation();
  return (
    <>
      <AppBar position="sticky"  sx={{
    backgroundColor: "#2d4a7c",
    color:"white",
    boxShadow: "none",
  }}>
        <Toolbar>
          {/* Logo */}
          <Typography variant="h6" sx={{ flexGrow: 1 }}>
            DigiSeva
          </Typography>

          {/* Desktop Menu */}
         <Box
  sx={{
    display: { xs: "none", md: "flex" },
    alignItems: "center",
    gap: 2
  }}
>
          {navLinks.map((link) => {
  const isActive = location.pathname === link.path;

  return (
    <Button
      key={link.label}
      component={Link}
      to={link.path}
      sx={{
        textTransform: "none",
        fontWeight: 500,
        color: isActive ? "#60a5fa" : "#fff", // active color
        position: "relative",

        "&::after": {
          content: '""',
          position: "absolute",
          left: 0,
          bottom: 0,
          width: isActive ? "100%" : "0%",
          height: "2px",
          backgroundColor: "#60a5fa",
          transition: "0.3s"
        },

        "&:hover::after": {
          width: "100%"
        }
      }}
    >
      {link.label}
    </Button>
  );
})}
          </Box>

          <Box
  sx={{
    display: { xs: "none", md: "block" },
    ml: 2
  }}
>
  <Button
    variant="contained"
    component={Link}
    to="/contact"
    sx={{
      background: "#2563eb",   // blue
      color: "#fff",
      textTransform: "none",
      fontWeight: 600,
      borderRadius: "8px",
      px: 3,
      "&:hover": {
        background: "#1d4ed8"
      }
    }}
  >
    Contact
  </Button>
</Box>

          {/* Mobile Menu Icon */}
          <IconButton
            color="inherit"
            edge="end"
            sx={{ display: { xs: "block", md: "none" } }}
            onClick={() => setOpen(true)}
          >
            
            <MenuIcon />
          </IconButton>
        </Toolbar>
      </AppBar>

      {/* Mobile Drawer */}
      <Drawer anchor="right" open={open} onClose={() => setOpen(false)}>
        <Box sx={{ width: 250 }}>
          <List>
            {navLinks.map((link) => (
              <ListItem key={link.label} disablePadding>
                <ListItemButton
                  component={Link}
                  to={link.path}
                  onClick={() => setOpen(false)}
                >
                  <ListItemText primary={link.label} />
                </ListItemButton>
              </ListItem>
            ))}
          </List>
        </Box>
      </Drawer>
    </>
  );
}