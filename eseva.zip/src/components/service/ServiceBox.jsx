import { Card, CardContent, Typography, Box } from "@mui/material";
import { useNavigate } from "react-router-dom";

export default function ServiceBox({ item }) {
  const navigate = useNavigate();

  console.log(item)
  const handleClick = () => {
  navigate(`/enquiry/${item.id}`);
};

  return (
<Card
  sx={{
    height: "100%",
    display: "flex",
    flexDirection: "column",
    borderRadius: 4,
    border: "1px solid transparent", // 👈 no visible border initially
    boxShadow: "none",
    position: "relative",
    transition: "all 0.3s ease",
    cursor:"pointer",
  backgroundColor: "#fdfaf2", 
    "&:hover": {
      transform: "translateY(-6px)",
      border: "1px solid #c89b3c", // 👈 shows only on hover
      boxShadow: "0 10px 25px rgba(0,0,0,0.08)"
    }
  }}

    >
      <CardContent
        sx={{
          flexGrow: 1,
          display: "flex",
          flexDirection: "column"
        }}
      >
        {/* Icon */}
        <Box
          sx={{
            width: 60,
            height: 60,
            borderRadius: 3,
            backgroundColor: item.bg,
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            fontSize: 28,
            mb: 2
          }}
        >
          {item.icon}
        </Box>

        {/* Number */}
        <Typography
          sx={{
            position: "absolute",
            top: 20,
            right: 20,
            fontSize: "40px",
            color: "#eee",
            fontWeight: 700
          }}
        >
          {item.id}
        </Typography>

        {/* Title */}
        <Typography variant="h6" sx={{ fontWeight: 600 }}>
          {item.title}
        </Typography>

        {/* Description (FIXED HEIGHT) */}
        <Typography
          sx={{
            fontSize: "14px",
            color: "#6b7280",
            minHeight: "60px", 
            py:2
          }}
        >
          {item.desc}
        </Typography>

        {/* Learn More */}
        <Typography
        onClick={()=>navigate(`${item.path}`)}
          // onClick={handleClick}

          sx={{
            color: "#c89b3c",
            fontWeight: 600,
            mt: "auto", // ✅ always push to bottom
            cursor: "pointer"
          }}
          
        >
          Enquiry Now →
        </Typography>
      </CardContent>
    </Card>
  );
}