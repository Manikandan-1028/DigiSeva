import { Box, TextField, Button, Typography,Paper } from "@mui/material";
import { useState } from "react";
import { submitToSheet } from "../../utils/submitToSheet";

export default function EnquiryForm({ serviceName, sheetUrl }) {
  const [form, setForm] = useState({
    name: "",
    phone: "",
    email: "",
    message: ""
  });

  const [errors, setErrors] = useState({});

  // ✅ VALIDATION
  const validate = () => {
    let newErrors = {};

    if (!form.name.trim()) {
      newErrors.name = "Name is required";
    }

    if (!form.phone) {
      newErrors.phone = "Phone is required";
    } else if (!/^[6-9]\d{9}$/.test(form.phone)) {
      newErrors.phone = "Enter valid 10-digit number";
    }

    if (!form.email) {
      newErrors.email = "Email is required";
    } else if (
      !/^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$/i.test(form.email)
    ) {
      newErrors.email = "Invalid email address";
    }

    if (!form.message.trim()) {
      newErrors.message = "Message is required";
    } else if (form.message.length < 10) {
      newErrors.message = "Message should be at least 10 characters";
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const [loading, setLoading] = useState(false);
  const [submitted, setSubmitted] = useState(false);

  // ✅ SUBMIT
  const handleSubmit = async () => {
    if (!validate()) return;

    setLoading(true);

    try {
      await submitToSheet({
        ...form,
        service: serviceName || "General Enquiry",
      }, sheetUrl);

      setSubmitted(true);
      setForm({
        name: "",
        phone: "",
        email: "",
        message: "",
      });
      setTimeout(() => setSubmitted(false), 5000);
    } catch (error) {
      console.error("Error!", error.message);
      alert("Something went wrong. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  return (
     <Paper
      elevation={4}
      sx={{
        width: "100%",
        maxWidth: 380,
        p: 3,
        borderRadius: 4,
        background: "#f9fafb"
      }}
    >
      <Typography fontWeight={700} fontSize={20} mb={2}>
        Register Now
      </Typography>

      {/* NAME */}
      <Typography sx={{ fontSize: 14, mb: 0.5 }}>
        Name <span style={{ color: "red" }}>*</span>
      </Typography>
      <TextField
        fullWidth
        placeholder="Enter your name"
        value={form.name}
        error={!!errors.name}
        helperText={errors.name}
        size="small"
        sx={{ mb: 2 }}
        onChange={(e) =>
          setForm({ ...form, name: e.target.value })
        }
      />

      {/* PHONE */}
      <Typography sx={{ fontSize: 14, mb: 0.5 }}>
        Mobile number <span style={{ color: "red" }}>*</span>
      </Typography>
      <TextField
        fullWidth
        placeholder="Enter your mobile number"
        value={form.phone}
        error={!!errors.phone}
        helperText={errors.phone}
        size="small"
        sx={{ mb: 2 }}
        onChange={(e) =>
          setForm({ ...form, phone: e.target.value })
        }
      />

      {/* EMAIL */}
      <Typography sx={{ fontSize: 14, mb: 0.5 }}>
        E-mail <span style={{ color: "red" }}>*</span>
      </Typography>
      <TextField
        fullWidth
        placeholder="Enter your email address"
        value={form.email}
        error={!!errors.email}
        helperText={errors.email}
        size="small"
        sx={{ mb: 2 }}
        onChange={(e) =>
          setForm({ ...form, email: e.target.value })
        }
      />

      {/* MESSAGE */}
      <Typography sx={{ fontSize: 14, mb: 0.5 }}>
        Your Message
      </Typography>
      <TextField
        fullWidth
        placeholder="Enter your message"
        multiline
        rows={3}
        value={form.message}
        error={!!errors.message}
        helperText={errors.message}
        size="small"
        sx={{ mb: 2 }}
        onChange={(e) =>
          setForm({ ...form, message: e.target.value })
        }
      />

      {/* TERMS */}
      <Typography sx={{ fontSize: 12, color: "#777", mb: 2 }}>
        ○ I agree with the Terms and Conditions
      </Typography>

      {/* BUTTON */}
      <Button
        variant="contained"
        fullWidth
        onClick={handleSubmit}
        disabled={loading}
        sx={{
          py: 1.2,
          borderRadius: 2,
          textTransform: "none",
          fontWeight: 600,
          background: "linear-gradient(90deg,#1d8cf8,#0d6efd)"
        }}
      >
        {loading ? "Sending..." : "Apply Now"}
      </Button>

      {/* SUCCESS */}
      {submitted && (
        <Typography
          sx={{
            mt: 2,
            textAlign: "center",
            color: "green",
            fontWeight: 600
          }}
        >
          ✓ Submitted Successfully!
        </Typography>
      )}
    </Paper>
    // <Box sx={{ maxWidth: 420 }}>
    //   <Typography fontWeight={600} mb={2}>
    //     Enquiry Form
    //   </Typography>

    //   <TextField
    //     fullWidth
    //     label="Name"
    //     value={form.name}
    //     error={!!errors.name}
    //     helperText={errors.name}
    //     sx={{ mb: 2 }}
    //     onChange={(e) =>
    //       setForm({ ...form, name: e.target.value })
    //     }
    //   />

    //   <TextField
    //     fullWidth
    //     label="Phone"
    //     value={form.phone}
    //     error={!!errors.phone}
    //     helperText={errors.phone}
    //     sx={{ mb: 2 }}
    //     onChange={(e) =>
    //       setForm({ ...form, phone: e.target.value })
    //     }
    //   />

    //   <TextField
    //     fullWidth
    //     label="Email"
    //     value={form.email}
    //     error={!!errors.email}
    //     helperText={errors.email}
    //     sx={{ mb: 2 }}
    //     onChange={(e) =>
    //       setForm({ ...form, email: e.target.value })
    //     }
    //   />

    //   <TextField
    //     fullWidth
    //     label="Message"
    //     multiline
    //     rows={4}
    //     value={form.message}
    //     error={!!errors.message}
    //     helperText={errors.message}
    //     sx={{ mb: 2 }}
    //     onChange={(e) =>
    //       setForm({ ...form, message: e.target.value })
    //     }
    //   />

    //   <Button 
    //     variant="contained" 
    //     fullWidth 
    //     onClick={handleSubmit}
    //     disabled={loading}
    //   >
    //     {loading ? "Sending..." : "Submit"}
    //   </Button>

    //   {submitted && (
    //     <Typography color="success.main" sx={{ mt: 2, textAlign: "center", fontWeight: 600 }}>
    //       ✓ Submitted Successfully!
    //     </Typography>
    //   )}
    // </Box>
  );
}