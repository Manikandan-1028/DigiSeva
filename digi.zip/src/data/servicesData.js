export const SERVICES = [
  {
    id: "01",
    title: "Global Education",
    path:"/globalEducation",

  
    icon: "🎓",
   
    desc: "Study abroad admissions, visa assistance, and complete passport support for aspiring students across India.",
    bg: "#e3f2fd",

    points: [
      "Study abroad guidance",
      "University admission support",
      "Visa assistance",
      "Scholarship help"
    ]
  },
  {
    id: "02",
   
    path:"/Business",
icon: "🤝",
    title: "Business Setup",
    desc: "Pvt Ltd, LLP, OPC registration, GST filing, Udyam certification and full compliance management.",
    bg: "#fff3e0",
    points: [
      "Pvt Ltd / LLP Registration",
      "GST Filing",
      "Udyam Registration",
      "Compliance support"
    ]
  },
    {
    id: "03",
    
    path:"/financial",
      icon: "₹",
    title: "Financial Services",
    desc: "Business loans for MSME, Mudra scheme, CMA data preparation and comprehensive project reports.",
    bg: "#fce4ec",
    points: [
      "Pvt Ltd / LLP Registration",
      "GST Filing",
      "Udyam Registration",
      "Compliance support"
    ]
  },
    {
    id: "04",
   
    path:"/tenders",
 icon: "⚖️",
    title: "Government Tenders",
    desc: "End-to-end tender search, bid preparation support, GeM portal registration and management.",
    bg: "#e8f5e9",
    points: [
      "Pvt Ltd / LLP Registration",
      "GST Filing",
      "Udyam Registration",
      "Compliance support"
    ]
  }
];