import {
  Box,
  Typography,
  TextField,
  Button,
  Paper
} from "@mui/material";
import EnquiryForm from "../../components/form/EnquiryForm";

export default function Business() {
  return (
    <Box
      sx={{
        py: 10,
        px: 2,
        background: "#f3f4f6"
      }}
    >
      {/* CENTER WRAPPER */}
      <Box
        sx={{
          maxWidth: "1000px",
          mx: "auto"
        }}
      >
        <Paper
          elevation={3}
          sx={{
            p: { xs: 3, md: 6 },
            borderRadius: 5,
            background: "#fff"
          }}
        >
          <Box
            sx={{
              display: "flex",
              flexDirection: { xs: "column", md: "row" },
              gap: 5
            }}
          >
            {/* LEFT SIDE */}
            <Box sx={{ flex: 1 }}>
              <Typography
                variant="h4"
                sx={{ fontWeight: 700, mb: 2 }}
              >
                Business Setup
              </Typography>

              <Typography sx={{ color: "#6b7280", mb: 3 }}>
                Fill out the form and our team will contact you shortly.
              </Typography>

              <Box sx={{ display: "flex", flexDirection: "column", gap: 2 }}>
                {[
                  "Quick response within 24 hours",
                  "Trusted by 25,000+ clients",
                  "Affordable & transparent pricing",
                  "End-to-end assistance"
                ].map((point, i) => (
                  <Box key={i} sx={{ display: "flex", gap: 1.5 }}>
                    <Box
                      sx={{
                        width: 8,
                        height: 8,
                        mt: "8px",
                        borderRadius: "50%",
                        backgroundColor: "#c89b3c"
                      }}
                    />
                    <Typography>{point}</Typography>
                  </Box>
                ))}
              </Box>
            </Box>

        <EnquiryForm/>
          </Box>
        </Paper>
      </Box>
    </Box>
  );
}