import { Box, Typography, TextField, Button, Paper } from "@mui/material";

export default function Newsletter() {
  return (
    <Box
      sx={{
        py: 12,
        px: 2,
        // background: "linear-gradient(135deg, #071421, #020617)",
        display: "flex",
        justifyContent: "center"
      }}
    >
      <Paper
        elevation={0}
        sx={{
          maxWidth: "700px",
          width: "100%",
          textAlign: "center",
          p: { xs: 4, md: 6 },
          borderRadius: 4,
        //   background: "rgba(255,255,255,0.03)",
        backgroundColor:"#2d4a7c",
          border: "1px solid rgba(255,255,255,0.08)",
          color:"white",
          backdropFilter: "blur(8px)",
          position: "relative",

          // subtle glow
          "&::before": {
            content: '""',
            position: "absolute",
            inset: 0,
            borderRadius: "inherit",
            background:
              "linear-gradient(135deg, rgba(200,155,60,0.15), transparent)",
            opacity: 0.4
          }
        }}
      >
        {/* CONTENT */}
        <Box sx={{ position: "relative" }}>
          <Typography
            variant="h4"
            sx={{ fontWeight: 700, mb: 1 }}
          >
            Subscribe to our Newsletter
          </Typography>

          <Typography
            sx={{
              color: "#9ca3af",
              mb: 4,
              fontSize: "0.95rem"
            }}
          >
            Get updates, offers and insights delivered to your inbox.
          </Typography>

          {/* INPUT + BUTTON */}
          <Box
            sx={{
              display: "flex",
              flexDirection: { xs: "column", sm: "row" },
              gap: 2
            }}
          >
            <TextField
              placeholder="Enter your email"
              fullWidth
              variant="outlined"
              InputProps={{
                sx: {
                  borderRadius: 2,
                  background: "rgba(255,255,255,0.05)",
                  color: "#fff",

                  "& fieldset": {
                    borderColor: "rgba(255,255,255,0.1)"
                  },
                  "&:hover fieldset": {
                    borderColor: "#c89b3c"
                  }
                }
              }}
            />

            <Button
              variant="contained"
              sx={{
                px: 4,
                py: 1.5,
                whiteSpace: "nowrap",
                fontWeight: 600,
                borderRadius: 2,
                background:
                  "linear-gradient(135deg, #c89b3c, #a67c2d)",
                boxShadow: "0 8px 20px rgba(200,155,60,0.3)",
                "&:hover": {
                  boxShadow: "0 12px 25px rgba(200,155,60,0.4)"
                }
              }}
            >
              Subscribe
            </Button>
          </Box>
        </Box>
      </Paper>
    </Box>
  );
}