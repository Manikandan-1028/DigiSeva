import { Box, Typography, Paper, Grid, Container } from "@mui/material";
import PublicIcon from "@mui/icons-material/Public";
import TrackChangesIcon from "@mui/icons-material/TrackChanges";
import BoltIcon from "@mui/icons-material/Bolt";
import LockIcon from "@mui/icons-material/Lock";

const features = [
  {
    icon: <PublicIcon />,
    title: "Nation-wide Reach",
    desc: "Serving clients across all 28 states with local expertise."
  },
  {
    icon: <TrackChangesIcon />,
    title: "Professional Experts",
    desc: "Specialists in finance, education and government processes."
  },
  {
    icon: <LockIcon />,
    title: "Secure & Certified",
    desc: "ISO 9001 certified. Data is protected with us securely."
  },
  {
    icon: <BoltIcon />,
    title: "Fast Processing",
    desc: "Workflows that cut processing time by up to 70%."
  }
];

export default function WhySection() {
  return (
    <Box
      sx={{
        py: 10,
        background: "#f7f9fc",
        textAlign:"center"
      }}
    >
      {/* ✅ ONE CENTERED CONTAINER */}
      <Container maxWidth="lg">
        
        {/* HEADER */}
        <Box textAlign="center" mb={6}>
          <Typography variant="h4" fontWeight={700}>
            Why{" "}
            <Box component="span" sx={{ color: "#3b82f6" }}>
              25,000+
            </Box>{" "}
            Clients Trust Us
          </Typography>

          <Typography
            sx={{
              mt: 2,
              color: "#6b7280",
              maxWidth: 700,
              mx: "auto"
            }}
          >
            For over 5 years, we've been the trusted partner for entrepreneurs,
            students, and businesses navigating India's regulatory landscape —
            with speed, transparency, and genuine care.
          </Typography>
        </Box>

<Box
  sx={{
    display: "flex",
    justifyContent: "center",
    flexWrap: "wrap",
    gap: 3,
    mt: 4
  }}
>
  {features.map((item, i) => (
    <Box
      key={i}
      sx={{
        width: {
          xs: "100%",
          sm: "90%",
          md: "48%"   // ✅ 2 per row
        },
        maxWidth: "500px",   // ✅ equal width
        display: "flex",
        justifyContent: "center"
      }}
    >
      <Paper
        elevation={0}
        sx={{
          display: "flex",
          gap: 2,
          alignItems: "flex-start",
          p: 3,
          borderRadius: 4,
          background: "#ffffff",
          boxShadow: "0 8px 24px rgba(0,0,0,0.05)",
          transition: "0.3s",

          width: "100%",
          minHeight: 120,

          "&:hover": {
            transform: "translateY(-5px)",
            boxShadow: "0 12px 30px rgba(0,0,0,0.08)"
          }
        }}
      >
        {/* ICON */}
        <Box
          sx={{
            width: 50,
            height: 50,
            minWidth: 50,
            borderRadius: 3,
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            background: "#eef2ff",
            color: "#3b82f6"
          }}
        >
          {item.icon}
        </Box>

        {/* TEXT */}
        <Box>
          <Typography fontWeight={600} mb={0.5}>
            {item.title}
          </Typography>

          <Typography
            sx={{
              color: "#6b7280",
              fontSize: "0.9rem",
              lineHeight: 1.6
            }}
          >
            {item.desc}
          </Typography>
        </Box>
      </Paper>
    </Box>
  ))}
</Box>

      </Container>
    </Box>
  );
}