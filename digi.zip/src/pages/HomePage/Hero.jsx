import React, { useState } from "react";
import {
  Box,
  Typography,
  TextField,
  Button,
  InputAdornment,
} from "@mui/material";
import ServicesSection from "./ServiceSection";
import WhySection from "./ClientsPage";
import Newsletter from "./NewsLetter";
import HowItWorks from "./HowItWorks";
// import SearchIcon from "@mui/icons-material/Search";

const HeroSection = () => {
  const [searchQuery, setSearchQuery] = useState("");

  const handleSearch = () => {
    console.log("Searching for:", searchQuery);
  };

  return (
   <>
    <Box
      sx={{
        position: "relative",
        minHeight: "550px",
        display: "flex",
        alignItems: "center",
        justifyContent: "space-between",
        px: { xs: 3, md: 8 },
        py: 6,
        background: "linear-gradient(to right, #1a365d, #2d4a7c)",
        color: "#fff",
        overflow: "hidden",
      }}
    >
      {/* Overlay */}
      <Box
        sx={{
          position: "absolute",
          inset: 0,
          backgroundColor: "rgba(26,54,93,0.85)",
          zIndex: 1,
        }}
      />

      {/* Left Content */}
      <Box
        sx={{
          position: "relative",
          zIndex: 2,
          maxWidth: "600px",
        }}
      >
        <Typography
          sx={{
            fontWeight: "bold",
            lineHeight: 1.2,
            mb: 2,
            fontSize: { xs: "1.8rem", md: "2.8rem" },
          }}
        >
          Your Gateway to{" "}
          <Box component="span" sx={{ color: "#d4a855" }}>
            500+ Government
          </Box>
          <br />
          <Box component="span" sx={{ color: "#d4a855" }}>
            & Corporate
          </Box>{" "}
          Services
        </Typography>

        <Typography
          sx={{
            color: "#ccc",
            mb: 4,
            fontStyle: "italic",
          }}
        >
          Trusted by 25,000+ Clients | 5+ Years of Excellence
        </Typography>

        {/* Search */}
        <Box
          sx={{
            display: "flex",
            gap: 1,
            background: "#fff",
            borderRadius: 2,
            p: 0.5,
            maxWidth: 550,
            boxShadow: 3,
          }}
        >
          <TextField
            fullWidth
            placeholder="Search for services... (GST, Loans, Study Abroad)"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && handleSearch()}
            size="small"
            sx={{
              flex: 1,
              "& .MuiOutlinedInput-root": {
                "& fieldset": { border: "none" },
              },
            }}
            InputProps={{
              startAdornment: (
                <InputAdornment position="start">
                  {/* <SearchIcon sx={{ color: "#999" }} /> */}
                </InputAdornment>
              ),
            }}
          />

          <Button
            onClick={handleSearch}
            sx={{
              backgroundColor: "#2d4a7c",
              color: "#fff",
              px: 3,
              borderRadius: 2,
              fontWeight: 600,
              "&:hover": {
                backgroundColor: "#1a365d",
              },
            }}
          >
            Find Now
          </Button>
        </Box>
      </Box>

      {/* Right Illustration */}
      <Box
        sx={{
          display: { xs: "none", md: "flex" },
          position: "relative",
          zIndex: 2,
        }}
      >
        <Box
          sx={{
            width: 150,
            height: 150,
            borderRadius: "50%",
            border: "3px solid #d4a855",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
          }}
        >
          <Box
            sx={{
              width: 100,
              height: 100,
              borderRadius: "50%",
              backgroundColor: "rgba(212,168,85,0.2)",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              fontSize: "2rem",
            }}
          >
            🛡️
          </Box>
        </Box>
      </Box>
    </Box>

    <ServicesSection/>

    <WhySection/>

    <HowItWorks/>

    <Newsletter/>

    
    </>
  );
};

export default HeroSection;