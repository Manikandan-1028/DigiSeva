import {
  Dialog,
  DialogTitle,
  DialogContent,
  TextField,
  Button
} from "@mui/material";
import { useState } from "react";
// import submitToSheet from "../../services/sheetApi";

export default function ServiceFormDialog({ open, onClose, service }) {
  const [form, setForm] = useState({ name: "", phone: "" });

  const handleSubmit = async () => {
    await submitToSheet({
      ...form,
      service
    });

    alert("Submitted!");
    onClose();
  };

  return (
    <Dialog open={open} onClose={onClose}>
      <DialogTitle>{service}</DialogTitle>

      <DialogContent>
        <TextField
          label="Name"
          fullWidth
          margin="normal"
          onChange={(e) => setForm({ ...form, name: e.target.value })}
        />

        <TextField
          label="Phone"
          fullWidth
          margin="normal"
          onChange={(e) => setForm({ ...form, phone: e.target.value })}
        />

        <Button variant="contained" fullWidth onClick={handleSubmit}>
          Submit
        </Button>
      </DialogContent>
    </Dialog>
  );
}