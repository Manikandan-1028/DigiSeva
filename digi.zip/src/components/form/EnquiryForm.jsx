import { Box, TextField, Button, Typography } from "@mui/material";
import { useState } from "react";

export default function EnquiryForm({ serviceName }) {
  const [form, setForm] = useState({
    name: "",
    phone: "",
    email: "",
    message: ""
  });

  const [errors, setErrors] = useState({});

  // ✅ VALIDATION
  const validate = () => {
    let newErrors = {};

    if (!form.name.trim()) {
      newErrors.name = "Name is required";
    }

    if (!form.phone) {
      newErrors.phone = "Phone is required";
    } else if (!/^[6-9]\d{9}$/.test(form.phone)) {
      newErrors.phone = "Enter valid 10-digit number";
    }

    if (!form.email) {
      newErrors.email = "Email is required";
    } else if (
      !/^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$/i.test(form.email)
    ) {
      newErrors.email = "Invalid email address";
    }

    if (!form.message.trim()) {
      newErrors.message = "Message is required";
    } else if (form.message.length < 10) {
      newErrors.message = "Message should be at least 10 characters";
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  // ✅ SUBMIT
  const handleSubmit = () => {
    if (!validate()) return;

    console.log({
      ...form,
      service: serviceName
    });

    alert("Submitted Successfully");

    setForm({
      name: "",
      phone: "",
      email: "",
      message: ""
    });
  };

  return (
    <Box sx={{ maxWidth: 420 }}>
      <Typography fontWeight={600} mb={2}>
        Enquiry Form
      </Typography>

      <TextField
        fullWidth
        label="Name"
        value={form.name}
        error={!!errors.name}
        helperText={errors.name}
        sx={{ mb: 2 }}
        onChange={(e) =>
          setForm({ ...form, name: e.target.value })
        }
      />

      <TextField
        fullWidth
        label="Phone"
        value={form.phone}
        error={!!errors.phone}
        helperText={errors.phone}
        sx={{ mb: 2 }}
        onChange={(e) =>
          setForm({ ...form, phone: e.target.value })
        }
      />

      <TextField
        fullWidth
        label="Email"
        value={form.email}
        error={!!errors.email}
        helperText={errors.email}
        sx={{ mb: 2 }}
        onChange={(e) =>
          setForm({ ...form, email: e.target.value })
        }
      />

      <TextField
        fullWidth
        label="Message"
        multiline
        rows={4}
        value={form.message}
        error={!!errors.message}
        helperText={errors.message}
        sx={{ mb: 2 }}
        onChange={(e) =>
          setForm({ ...form, message: e.target.value })
        }
      />

      <Button variant="contained" fullWidth onClick={handleSubmit}>
        Submit
      </Button>
    </Box>
  );
}