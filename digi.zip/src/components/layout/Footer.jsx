import { Box, Typography } from "@mui/material";

export default function Footer() {
  return (
    <Box sx={{ textAlign: "center", p: 2, mt: 4, bgcolor: "#111", color: "#fff" }}>
      <Typography variant="body2">
        © 2026 DigiSeva India
      </Typography>
    </Box>
  );
}